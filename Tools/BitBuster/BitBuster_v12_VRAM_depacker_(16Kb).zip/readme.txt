
Bitbuster v1.2 VRAM Depacker v1.1
---------------------------------

This routine makes a direct VRAM decompression of BitBuster v1.2 files, on all MSX generations.

For now, it is limited to 0000h - 3FFFh VRAM addresses, because higher addresses need a lot of extra code to handle them through of the use of VDP register r#14. I plan to remove this limit in the forthcoming releases, although it might be necessary to make a separate release for it, due to probable speed decrease.

It is largely based on the depack routine provided with the BitBuster v1.2 package, as well as the SEGA aPLib libraries, both based on the LZ77 (de)compression algorythm. Everything was already here and there, all I did was put existing things together :)

Thanks to Arjan, ARTRAG, dvik and jltursan for their help and support.


How to use the VRAM depacker
----------------------------

Simply set HL to source address, DE to VRAM destination address and make a call to the routine.
Beware that in order to prevent data stream corruption, the routine is executed between EI/DI instructions.

Please note that the code is formatted for use with asMSX, hence those weird "[]" instead of "()" ... ;)


Important notices
-----------------

. VDP ports addresses

Standard VDP ports addresses (98h and 99h) are used in the source code, this should ensure that the code works with 99.9% of the MSX machines. However, the MSX standard states that the correct ports addresses are always stored in BIOS ROM 0006h and 0007h adresses. You may need to replace those the VDP ports addresses with those value if you are using some exotic hardware (eg. MSX2 upgrade packages for MSX1s).

. VDP timing

NOP instructions are added in the source code where VDP timing may be critical (between VDP ports access). They are identified by the comment "; VDP timing". I have only added one NOP instruction, but should you experience problems involving VRAM data corruption, you may have to add additional NOP instructions at those specific locations. This will of course have an effect on the routine speed.

The VDP timing might get very critical in some specific situations, SCREEN2 on a MSX1 being one of them. The use of sprites may also be an important factor.

On the other hand, MSX2 hardware (and above) are known to have a quicker VDP (V9938 and V9958), so you may try to remove those NOP instructions if your application is limited to those machines.

Please note that emulators do not behave like the real hardware, so there is no VDP timing issue when using them.


Contact info
------------

You can contact me at : metalion@orange.fr for further information or if you have questions.


Version history
---------------

22.02.2008	v1.1	Added NOP instructions for VDP timing
19.02.2008	v1.0	Initial release

